import axios from 'axios';
import Cookies from 'js-cookie';
const API_BASE = `${import.meta.env.VITE_API_BASE}/appointments`

export const getDoctors = async () => {
  try {
    const headers = {
        authorization : Cookies.get('token')
    }
    console.log(headers);
    const res = await axios.get(`${API_BASE}/getdoctor` , {headers}  );
    // console.log(res)
    return res.data; 
  } catch (error) {
    throw error.response?.data || error.message;
  }
};
export const getTopDoctors = async () => {
  try {
    const headers = {
      authorization: Cookies.get('token'),
    };
    console.log(headers);

    const res = await axios.get(`${API_BASE}/top-doctors`, { headers });
    return res.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};
