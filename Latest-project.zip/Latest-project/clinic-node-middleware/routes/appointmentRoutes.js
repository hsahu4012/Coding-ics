const express = require('express');
const router = express.Router();
const authorizeRole = require('../middleware/roleMiddleware')
const appointmentController = require('../controllers/appointmentController');
const authenticateToken = require('../middleware/authMiddleware');

// Book appointment (POST /api/appointments/book)
router.post(
  '/book',
  authenticateToken,
  authorizeRole('PATIENT'), 
  appointmentController.bookAppointment
);
// get doctorlist appointment (get /api/appointments/getdoctor)
router.get('/getdoctor', authenticateToken, authorizeRole('PATIENT'), appointmentController.getDoctorList);
// get top doctors (get /api/appointments/getdoctor)
router.get('/top-doctors', authenticateToken, authorizeRole('PATIENT'), appointmentController.getTopDoctorList);

// Cancel appointment (PUT /api/appointments/cancel/:id?username=&role=)
router.put('/cancel', authenticateToken, authorizeRole('PATIENT','DOCTOR'), appointmentController.cancelAppointment);

// Reschedule appointment (PUT /api/appointments/reschedule?username=&role=)
router.put('/reschedule', authenticateToken, authorizeRole('PATIENT','DOCTOR'), appointmentController.rescheduleAppointment);

// Complete appointment (PUT /api/appointments/complete?doctorUsername=)
router.put('/complete', authenticateToken, authorizeRole('DOCTOR'), appointmentController.completeAppointment);

// Get active appointments for patient (GET /api/appointments/doctor/active?username=)
router.get('/active', authenticateToken, authorizeRole('PATIENT', 'DOCTOR'), appointmentController.getActiveAppointments);

// Get appointment history (GET /api/appointments/history?username=&role=)
router.post('/feedback', authenticateToken,authorizeRole('PATIENT'), appointmentController.giveFeedback);

// Get appointment history (GET /api/appointments/history?username=&role=)
router.get('/history', authenticateToken,authorizeRole('PATIENT', 'DOCTOR'), appointmentController.getAppointmentHistoryForUser);

// Search completed appointments by patient (GET /api/appointments/doctor/search?doctorUsername=&patientUsername=)
router.get('/doctor/search', authenticateToken, authorizeRole('DOCTOR'), appointmentController.searchCompletedAppointmentsByPatient);

module.exports = router;




