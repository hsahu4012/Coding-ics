import React, { useEffect, useState } from "react";
import '../styles/AppointmentHistory.css'
import {
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Pagination,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import Rating from "@mui/material/Rating";
import { useDispatch, useSelector } from "react-redux";
import { fetchCompletedAppointments } from "../redux/slices/appointmentSlice";
import axios from "axios";
import { toast } from "react-toastify";
import Cookies from "js-cookie";

const AppointmentHistory = () => {
  const dispatch = useDispatch();
  const { completed } = useSelector((state) => state.appointments);
  const { user } = useSelector((state) => state.auth);
  const [search, setSearch] = useState("");

  // Pagination state
  const [page, setPage] = useState(1);
  const appointmentsPerPage = 5;

  // Sorting state
  const [sortField, setSortField] = useState("date"); // "date" | "doctor" | "diagnosis"
  const [sortOrder, setSortOrder] = useState("desc"); // "asc" | "desc"

  // Feedback modal states
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackComment, setFeedbackComment] = useState("");

  const BASE_URL = `${import.meta.env.VITE_API_BASE}/appointments`;

  useEffect(() => {
    dispatch(fetchCompletedAppointments());
  }, [dispatch]);

  // function to handle sorting toggling
  const handleSort = (field) => {
    if (sortField === field) {
      // toggle order if same field is selected
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc"); // default to ascending
    }
  };

  // Filter appointments based on user role's search field:
  // DOCTOR: search by patient name
  // PATIENT: search by doctor name
  const filtered = completed.filter((appt) => {
    if (user.role === "DOCTOR") {
      return appt.patientName.toLowerCase().includes(search.toLowerCase());
    } else if (user.role === "PATIENT") {
      return appt.doctorName.toLowerCase().includes(search.toLowerCase());
    }
    return true;
  });

  // Sorting function
  const sortedAppointments = filtered.sort((a, b) => {
    const factor = sortOrder === "asc" ? 1 : -1;
    if (sortField === "date") {
      return factor * (new Date(a.dateTime) - new Date(b.dateTime));
    }
    if (sortField === "doctor") {
      // if user is a doctor, sort by patient name; else by doctor name:
      const aValue = (user.role === "DOCTOR" ? a.patientName : a.doctorName)?.toLowerCase() || "";
      const bValue = (user.role === "DOCTOR" ? b.patientName : b.doctorName)?.toLowerCase() || "";
      if (aValue < bValue) return -1 * factor;
      if (aValue > bValue) return factor;
      return 0;
    }
    if (sortField === "diagnosis") {
      const aValue = a.diagnosis?.toLowerCase() || "";
      const bValue = b.diagnosis?.toLowerCase() || "";
      if (aValue < bValue) return -1 * factor;
      if (aValue > bValue) return factor;
      return 0;
    }
    return 0;
  });

  // Compute pagination values
  const totalPages = Math.ceil(sortedAppointments.length / appointmentsPerPage);
  const currentAppointments = sortedAppointments.slice(
    (page - 1) * appointmentsPerPage,
    page * appointmentsPerPage
  );

  // Reset to first page when search or appointments changes
  useEffect(() => {
    setPage(1);
  }, [search, completed]);

  // Open the feedback modal and set the selected appointment in state
  const handleOpenFeedback = (appt) => {
    setSelectedAppointment(appt);
    setFeedbackRating(0);
    setFeedbackComment("");
    setFeedbackOpen(true);
  };

  const handleCloseFeedback = () => {
    setFeedbackOpen(false);
    setSelectedAppointment(null);
  };

  // Save feedback API call
  const handleSaveFeedback = async () => {
    if (user.role !== "PATIENT") {
      toast.error("Only patients can give feedback.");
      return;
    }
    if (!feedbackRating || feedbackRating < 1 || feedbackRating > 5) {
      toast.error("Please select a valid rating (between 1 and 5).");
      return;
    }
    const payload = {
      feedbackRating: feedbackRating,
      feedbackComment,
      patientUsername: user.username,
      doctorUsername: selectedAppointment.doctorUsername,
      appointmentId: selectedAppointment.appointmentId,
    };

    try {
      const headers = {
        authorization: Cookies.get("token"),
      };
      await axios.post(`${BASE_URL}/feedback`, payload, {
        headers,
        withCredentials: true,
      });
      toast.success("Feedback saved successfully.");
      dispatch(fetchCompletedAppointments());
      handleCloseFeedback();
    } catch (error) {
      toast.error(error.response?.data || "Failed to save feedback.");
    }
  };

  return (
    <Box className="appointment-history-container" sx={{ maxWidth: 900, mx: "auto", mt: 4, p: 2 }}>
      <Typography variant="h5" gutterBottom className="appointment-history-title">
        Appointment History
      </Typography>

      {(user.role === "DOCTOR" || user.role === "PATIENT") && (
        <TextField
          label={`Search by ${user.role === "DOCTOR" ? "Patient" : "Doctor"} Name`}
          fullWidth
          margin="normal"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="appointment-history-search"
        />
      )}

      <Table className="appointment-history-table">
        <TableHead>
          <TableRow>
            <TableCell>
              <b onClick={() => handleSort("date")} style={{ cursor: "pointer" }}>
                Date/Time {sortField === "date" ? (sortOrder === "asc" ? "↑" : "↓") : ""}
              </b>
            </TableCell>
            <TableCell>
              <b onClick={() => handleSort("doctor")} style={{ cursor: "pointer" }}>
                {user.role === "DOCTOR" ? "Patient" : "Doctor"} {sortField === "doctor" ? (sortOrder === "asc" ? "↑" : "↓") : ""}
              </b>
            </TableCell>
            <TableCell>
              <b onClick={() => handleSort("diagnosis")} style={{ cursor: "pointer" }}>
                Diagnosis {sortField === "diagnosis" ? (sortOrder === "asc" ? "↑" : "↓") : ""}
              </b>
            </TableCell>
            <TableCell>
              <b>Comments</b>
            </TableCell>
            <TableCell>
              <b>Feedback</b>
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {currentAppointments.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} align="center">
                No completed appointments found.
              </TableCell>
            </TableRow>
          ) : (
            currentAppointments.map((appt) => (
              <TableRow key={appt.appointmentId}>
                <TableCell>{new Date(appt.dateTime).toLocaleString()}</TableCell>
                <TableCell>
                  {user.role === "DOCTOR" ? appt.patientName : appt.doctorName}
                </TableCell>
                <TableCell>{appt.diagnosis}</TableCell>
                <TableCell>{appt.comments}</TableCell>
                <TableCell>
                  {appt.feedbackRating || appt.feedbackComment ? (
                    <>
                      <Typography variant="body2">
                        <Rating
                          value={parseInt(appt.feedbackRating, 10)}
                          readOnly
                          precision={1}
                          sx={{ "& .MuiRating-iconFilled": { color: "#ffb400" } }}
                        />
                      </Typography>
                      <Typography variant="body2">
                        {appt.feedbackComment}
                      </Typography>
                    </>
                  ) : user.role === "PATIENT" ? (
                    <Button variant="contained" size="small" className="give-feedback-btn" onClick={() => handleOpenFeedback(appt)}>
                      Give Feedback
                    </Button>
                  ) : (
                    <Typography variant="body2">Not Given Yet</Typography>
                  )}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {totalPages > 1 && (
        <Box className="appointment-history-pagination" sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
          <Pagination
            count={totalPages}
            page={page}
            onChange={(event, value) => setPage(value)}
            color="primary"
          />
        </Box>
      )}

      {/* Feedback Modal Dialog */}
      <Dialog open={feedbackOpen} onClose={handleCloseFeedback} fullWidth maxWidth="sm">
        <DialogTitle>Give Feedback</DialogTitle>
        <DialogContent>
          <Typography variant="subtitle1" gutterBottom>
            {selectedAppointment &&
              `Appointment on ${new Date(selectedAppointment.dateTime).toLocaleString()}`}
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", mt: 1, mb: 2 }}>
            <Typography component="legend" sx={{ mr: 2 }}>
              Rating:
            </Typography>
            <Rating
              name="feedback-rating"
              value={feedbackRating}
              onChange={(event, newValue) => {
                if (newValue) setFeedbackRating(newValue);
              }}
              precision={1}
              max={5}
              sx={{ "& .MuiRating-iconFilled": { color: "#ffb400" } }}
            />
          </Box>
          <TextField
            fullWidth
            label="Feedback Comment"
            multiline
            rows={3}
            value={feedbackComment}
            onChange={(e) => setFeedbackComment(e.target.value)}
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseFeedback}>Cancel</Button>
          <Button variant="contained" className="save-feedback-btn" onClick={handleSaveFeedback}>
            Save Feedback
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AppointmentHistory;