const jwtUtil = require('../utils/jwtUtil');

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ error: 'Authorization header missing' });

  // const token = authHeader.split(' ')[1];
  const token = authHeader;
  // console.log(token);
  if (!token) return res.status(401).json({ error: 'Token missing' });

  try {
    const payload = jwtUtil.verifyAccessToken(token);
    req.user = payload;

    console.log(req.user); 
     
    console.log("Token Validation Succeeed");
    next();
  } catch (err) {
    res.status(403).json({ error: 'Invalid or expired token' });
  }
}

module.exports = authenticateToken;

