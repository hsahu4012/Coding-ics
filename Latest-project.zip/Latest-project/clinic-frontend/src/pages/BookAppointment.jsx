import { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useNavigate, useSearchParams } from "react-router-dom";
import '../styles/BookAppointments.css'
import {
  Typography,
  Box,
  TextField,
  MenuItem,
  Button,
  Container,
} from "@mui/material";

import { useSelector, useDispatch } from "react-redux";
// 2 APIs 
import {
  fetchActiveAppointments,
  createAppointment,
} from "../redux/slices/appointmentSlice";

import { getDoctors } from "../api/doctorApi";

// Helper to get current time in "HH:MM" format
const getCurrentTimeString = () => {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();

  // Zero-pad hours and minutes as needed
  return `${hours.toString().padStart(2, "0")}:${minutes
    .toString()
    .padStart(2, "0")}`;
};

const BookAppointment = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  const [searchParams] = useSearchParams();
  const doctorFromQuery = searchParams.get("doctor");

  // console.log(doctorFromQuery)
  // Compute today's date in "YYYY-MM-DD"
  const today = new Date().toISOString().split("T")[0];
  // Compute current time in "HH:MM" format
  const currentTime = getCurrentTimeString();

  // Initialize form state with default current date and time
  const [form, setForm] = useState({
    doctorUsername: "",
    date: today,
    time: currentTime,
  });
  const [formError, setFormError] = useState("");


  // Set the min attribute for the Time input if the selected date is today.
  const timeInputProps =
    form.date === today ? { min: getCurrentTimeString() } : {};

  // Doctors list state
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    // Fetch doctors list on mount
    const fetchDoctors = async () => {
      try {
        const data = await getDoctors();
        console.log(data);
        setDoctors(data);

        if (
          doctorFromQuery &&
          data.some((doc) => doc.username === doctorFromQuery)
        ) {
          setForm((prev) => ({ ...prev, doctorUsername: doctorFromQuery }));
        }

        else if (data.length > 0)
          setForm((prev) => ({ ...prev, doctorUsername: data[0].username }));
      } catch (err) {
        setFormError("Failed to load doctors.");
      }
    };
    fetchDoctors();

    // Fetch active appointments
    // dispatch(fetchActiveAppointments());
  }, [dispatch]);

  // Form input change handler
  const handleInputChange = (e) => {
    setFormError("");
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Validate form before submit
  const validateForm = () => {
    if (!form.doctorUsername) {
      setFormError("Please select a doctor.");
      return false;
    }
    if (!form.date) {
      setFormError("Please select date.");
      return false;
    }
    if (!form.time) {
      setFormError("Please select time.");
      return false;
    }
    const dateTime = new Date(`${form.date}T${form.time}`);
    if (dateTime < new Date()) {
      toast.error("Cannot book appointment in the past.");
      return false;
    }
    return true;
  };

  // Submit booking
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    const appointmentData = {
      doctorUsername: form.doctorUsername,
      patientUsername: user.username,
      newDateTime: new Date(`${form.date}T${form.time}`).toISOString(),
    };

    try {
      const res = await dispatch(createAppointment(appointmentData));
      if(res.type !== 'appointments/book/rejected'){
        toast.success("Appointment Booked Successfully");
        navigate('/active')
      }
      setForm({
        ...form,
        date: today,
        time: currentTime,
      });
    } catch (err) {
      setFormError(err.message || "Failed to book appointment.");
    }
  };





  return (
    <Container maxWidth="sm" className="book-appointment-container">
      <Box sx={{ mt: 4, p: 2 }}>
        <Typography variant="h5" gutterBottom className="book-appointment-title">
          Book Appointment
        </Typography>

        <form onSubmit={handleSubmit} className="book-appointment-form">
          <TextField
            select
            label="Doctor"
            name="doctorUsername"
            value={form.doctorUsername}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
            required
            className="book-appointment-input"
          >
            {doctors.map((doc) => (
              <MenuItem key={doc.username} value={doc.username}>
                Dr. {doc.name} ({doc.username})
              </MenuItem>
            ))}
          </TextField>

          <TextField
            label="Date"
            type="date"
            name="date"
            value={form.date}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
            InputLabelProps={{ shrink: true }}
            inputProps={{ min: today }}
            required
            className="book-appointment-input"
          />

          <TextField
            label="Time"
            type="time"
            name="time"
            value={form.time}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
            InputLabelProps={{ shrink: true }}
            inputProps={timeInputProps}
            required
            className="book-appointment-input"
          />

          {formError && (
            <Typography color="error" className="book-appointment-error" sx={{ mt: 1 }}>
              {formError}
            </Typography>
          )}

          <Button type="submit" variant="contained" className="book-appointment-btn" sx={{ mt: 2 }}>
            Book Appointment
          </Button>
        </form>
      </Box>
    </Container>
  );
};

export default BookAppointment;