import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { login, signup } from "../../redux/slices/authSlice";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "../../styles/SignupForm.css";
import { getSecurityQuestions } from "../../api/authApi";
import axios from "axios";
const BASE_URL = `${import.meta.env.VITE_API_BASE}/auth`;
const SignupForm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, user } = useSelector((state) => state.auth);
  const [showPassword, setShowPassword] = useState(false);
  // List of available security questions from the API
  const [securityQuestionsList, setSecurityQuestionsList] = useState([]);

  // form state with top-level fields and security questions array.
  const [form, setForm] = useState({
    username: "",
    name: "",
    email: "",
    phoneNumber: "",
    password: "",
    role: "",
    securityQuestions: [
      { securityQuestion: "", securityAnswer: "" },
      { securityQuestion: "", securityAnswer: "" },
      { securityQuestion: "", securityAnswer: "" },
    ],
  });

  // Validation errors;
  const [errors, setErrors] = useState({
    username: "",
    name: "",
    email: "",
    phoneNumber: "",
    password: "",
    role: "",
    securityQuestions: [
      { securityQuestion: "", securityAnswer: "" },
      { securityQuestion: "", securityAnswer: "" },
      { securityQuestion: "", securityAnswer: "" },
    ],
  });

  // Fetching All SecurityQuestions from API
  useEffect(() => {
    const fetchSecurityQuestions = async () => {
      try {
        const data = await getSecurityQuestions();
        console.log("Fetched Security Questions:", data);
        setSecurityQuestionsList(data);
      } catch (err) {
        console.error("Failed to load Security Questions:", err);
      }
    };

    fetchSecurityQuestions();
  }, []);

  // My Validators
  const validateUsername = (value) => {
    if (!/^[a-zA-Z0-9_]{5,30}$/.test(value))
      return "Username must be between 5 to 30 characters";
    return "";
  };

  const validateName = (value) => {
    if (!/^[a-zA-Z\s]{5,30}$/.test(value))
      return "Name must be between 5 to 30 characters.";
    return "";
  };

  const validateEmail = (value) => {
    if (!/^\S+@\S+\.\S+$/.test(value)) return "Enter a valid email address.";
    if (
      !/^(?!.*\.\.)[a-zA-Z0-9._%+-]+@(?!.*\.\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(
        value
      )
    )
      return "Email must be properly formatted.";

    if (/@[._%+-]/.test(value))
      return "Email cannot have a symbol immediately after '@'.";
    
    return "";
  };

  const validatePhoneNumber = (value) => {
    if (!/^\d{10}$/.test(value)) return "Enter a valid 10-digit phone number.";
    if (/^(\d)\1{9}$/.test(value))
      return "Phone number cannot contain all identical digits.";
    return "";
  };

  const validatePassword = (value) => {
    // Check for minimum length.
    // if (/\s/.test(value)) return "Password cannot contain spaces.";
    if (value.length < 8) {
      return "Password must be at least 8 characters long.";
    }
    // Check for at least one uppercase letter.
    if (!/[A-Z]/.test(value)) {
      return "Password must include at least one uppercase letter.";
    }
    // Check for at least one lowercase letter.
    if (!/[a-z]/.test(value)) {
      return "Password must include at least one lowercase letter.";
    }
    // Check for at least one number.
    if (!/\d/.test(value)) {
      return "Password must include at least one number.";
    }
    // Check for at least one special character (@, $, !, %, *, #, ? &).
    if (!/[@$!%*#?&]/.test(value)) {
      return "Password must include at least one special character (@$!%*#?&).";
    }
    return "";
  };

  // Validator for Role field
  const validateRole = (value) => {
    if (!value || value.trim() === "") {
      return "Please select your role.";
    }
    if (value !== "PATIENT" && value !== "DOCTOR") {
      return "Invalid role selected.";
    }
    return "";
  };

  const validateField = (name, value) => {
    switch (name) {
      case "username":
        return validateUsername(value);
      case "name":
        return validateName(value);
      case "email":
        return validateEmail(value);
      case "phoneNumber":
        return validatePhoneNumber(value);
      case "password":
        return validatePassword(value);
      case "role":
        return validateRole(value);
      default:
        return "Invalid field name provided.";
    }
  };

  //Handling Username and Email
  const handleUsernameAndEmail = (e) => {
    e.preventDefault();
    setForm((form) => ({ ...form, [e.target.name]: e.target.value }));
    const { name, value } = e.target;
    const error = validateField(name, value);
    setErrors((prev) => ({ ...prev, [name]: error }));
  };

  //Handling Username and Email check from API
  const handleOnBlurUsernameAndEmail = async (e) => {
    e.preventDefault();
    setForm((form) => ({ ...form, [e.target.name]: e.target.value }));
    const { name, value } = e.target;

    if (name === "username" && value.length > 6) {
      //**************************************************************************** */
      console.log(name, value);
      const response = await axios.get(`${BASE_URL}/username-check`, {
        params: { username: value },
      });
      console.log(response.data);
      //**************************************************************************** */
      if (response.data && response.data !== "Username Available") {
        const error = response.data;
        setErrors((prev) => ({ ...prev, [name]: error }));
      }
    }
    if (name === "email" && validateEmail(value) === "") {
      //**************************************************************************** */
      const response = await axios.get(`${BASE_URL}/email-check`, {
        params: { email: value },
      });
      if (response.data && response.data !== "Email Available") {
        //**************************************************************************** */
        const error = response.data;
        setErrors((prev) => ({ ...prev, [name]: error }));
      }
    }
  };

  //Handling Name and my PhoneNumber
  const handleNameAndPhoneNumber = (e) => {
    e.preventDefault();
    setForm((form) => ({ ...form, [e.target.name]: e.target.value }));
    const { name, value } = e.target;
    const error = validateField(name, value);
    setErrors((prev) => ({ ...prev, [name]: error }));
  };

  // Handling Role Change
  const handleRoleChange = (e) => {
    const value = e.target.value;
    setForm((prev) => ({ ...prev, role: value }));
    const error = validateField("role", value);
    setErrors((prev) => ({ ...prev, role: error }));
  };

  // Separate validation for security question fields
  const validateSecurityField = (field, value) => {
    let error = "";
    if (field === "securityQuestion") {
      if (!value) {
        error = "Please select a security question.";
      }
    }
    if (field === "securityAnswer") {
      if (!value || value.trim().length < 3) {
        error = "Answer must be at least 3 characters long.";
      }
    }
    return error;
  };

  // Handling Password Change
  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, password: value }));
    const error = validateField(name, value);
    setErrors((prev) => ({ ...prev, [name]: error }));
  };

  // Handling Question Change. here I am removing all that question that are previously selected
  const handleQuestionChange = (index, question) => {
    setForm((prevState) => ({
      ...prevState,
      securityQuestions: prevState.securityQuestions.map((qna, i) =>
        i === index ? { ...qna, securityQuestion: question } : qna
      ),
    }));
    // Performing validation as soon as the input changes
    const error = validateSecurityField("securityQuestion", question);
    setErrors((prev) => {
      const newSecurityErrors = [...prev.securityQuestions];
      newSecurityErrors[index] = {
        ...newSecurityErrors[index],
        securityQuestion: error,
      };
      return { ...prev, securityQuestions: newSecurityErrors };
    });
  };

  // Handling Answer Change
  const handleAnswerChange = (index, answer) => {
    setForm((prevState) => ({
      ...prevState,
      securityQuestions: prevState.securityQuestions.map((qna, i) =>
        i === index ? { ...qna, securityAnswer: answer } : qna
      ),
    }));
    const error = validateSecurityField("securityAnswer", answer);
    setErrors((prev) => {
      const newSecurityErrors = [...prev.securityQuestions];
      newSecurityErrors[index] = {
        ...newSecurityErrors[index],
        securityAnswer: error,
      };
      return { ...prev, securityQuestions: newSecurityErrors };
    });
  };

  // onBlur handler for security question and answer
  const handleSecurityBlur = (index, field, value) => {
    const error = validateSecurityField(field, value);
    setErrors((prev) => {
      const newSecurityErrors = [...prev.securityQuestions];
      newSecurityErrors[index] = {
        ...newSecurityErrors[index],
        [field]: error,
      };
      return { ...prev, securityQuestions: newSecurityErrors };
    });
  };

  // Handling my Form Submit
  const handleSubmit = (e) => {
    e.preventDefault();

    // Performing my final validation before submitting
    let formValid = true;
    let newErrors = { ...errors };

    // Validate top-level fields
    ["username", "name", "email", "phoneNumber", "password", "role"].forEach(
      (field) => {
        const error = validateField(field, form[field]);
        if (error) {
          formValid = false;
        }
        newErrors[field] = error;
      }
    );

    // Validating security questions (always validated, independent from other fields)
    const securityErrors = form.securityQuestions.map((qna) => {
      let qError = {};
      qError.securityQuestion = !qna.securityQuestion
        ? "Please select a security question."
        : "";
      qError.securityAnswer =
        !qna.securityAnswer || qna.securityAnswer.trim().length < 3
          ? "Answer must be at least 3 characters long."
          : "";
      if (qError.securityQuestion || qError.securityAnswer) formValid = false;
      return qError;
    });
    newErrors.securityQuestions = securityErrors;

    setErrors(newErrors);

    if (!formValid) {
      toast.error("Please fix the errors on the form.");
      return;
    }

    // Submiting the form via dispatch if all validations pass
    dispatch(signup(form))
      .unwrap()
      .then(() => {
        // If success Then Trying to Login using those data Automatically
        dispatch(login(form))
          .unwrap()
          .then(() => {
            toast.success("Signup successful & Login successful!");
          })
          .catch((err) => {
            toast.error(
              err || err?.message || "Login failed. Please try again."
            );
          });
      })
      .catch((err) => {
        console.error(err);
        toast.error(err?.message || err || "Signup failed. Please try again.");
      });
  };

  // Redirecting to Dashboard based on User Role
  useEffect(() => {
    if (user) {
      console.log("Redirecting based on role:", user.role);
      if (user.role === "DOCTOR") {
        navigate("/");
      } else if (user.role === "PATIENT") {
        navigate("/");
      }
    }
  }, [user, navigate]);

  return (
    <div className="signup-container">
      <h2>Create Your Account</h2>
      <form onSubmit={handleSubmit} className="signup-form">
        {/* For Left Column of the signup page */}
        <div className="left-column">
          {/* For Username and Email. I have called here an api to check exist or not. also handling onChange events for validations */}
          {["username", "email"].map((field) => (
            <div key={field} className="input-group floating-label-group">
              {/* <label>{field.charAt(0).toUpperCase() + field.slice(1)}</label> */}
              <input
                name={field}
                required
                value={form[field]}
                placeholder=""
                onChange={handleUsernameAndEmail}
                onBlur={handleOnBlurUsernameAndEmail}
                onInput={(e) => {
                  if (field === "username") {
                    e.target.value = e.target.value
                      .replace(/[^a-zA-Z0-9_]/g, "")
                      .slice(0, 30);
                  }
                  if (field === "email") {
                    e.target.value = e.target.value
                      .replace(/[^a-zA-Z0-9@.]/g, "")
                  }
                }}
              />
              <label htmlFor="username">
                {field.charAt(0).toUpperCase() + field.slice(1)}
              </label>
              {errors[field] && (
                <span className="error-text">{errors[field]}</span>
              )}
            </div>
          ))}

          {/* For name and phoneNumber. Here I am handling only validations on onChange, onKeyPress, onInput events */}
          {["name", "phoneNumber"].map((field) => (
            <div key={field} className="input-group floating-label-group">
              {/* <label>{field.charAt(0).toUpperCase() + field.slice(1)}</label> */}
              <input
                name={field}
                required
                value={form[field]}
                placeholder=""
                onChange={handleNameAndPhoneNumber}
                onKeyPress={(e) => {
                  if (field === "name" && !/^[a-zA-Z ]$/.test(e.key)) {
                    e.preventDefault();
                  }
                  if (field === "phoneNumber" && !/^\d$/.test(e.key)) {
                    e.preventDefault();
                  }
                }}
                onInput={(e) => {
                  if (field === "name") {
                    let value = e.target.value
                      .replace(/[^a-zA-Z ]/g, "")
                      .slice(0, 30)
                      .replace(/\b\w/g, (char) => char.toUpperCase());
                    e.target.value = value;
                  }
                  if (field === "phoneNumber") {
                    e.target.value = e.target.value
                      .replace(/\D/g, "")
                      .slice(0, 10);
                  }
                }}
              />
              <label htmlFor="name">
                {field.charAt(0).toUpperCase() + field.slice(1)}
              </label>
              {errors[field] && (
                <span className="error-text">{errors[field]}</span>
              )}
            </div>
          ))}

          {/* For Role. Now handled like a securityQuestion select with validations */}
          <div className="input-group">
            <center></center>
            <select name="role" value={form.role} onChange={handleRoleChange}>
              <option value="">Choose Role</option>
              <option value="PATIENT">Patient</option>
              <option value="DOCTOR">Doctor</option>
            </select>
            {errors.role && <span className="error-text">{errors.role}</span>}
          </div>
        </div>

        {/* For Right Column of the signup page */}
        <div className="right-column">
          {/* For Password. Handling password change with validations */}
          <div className="input-group floating-label-group">
            {/* <label>Password</label> */}
            <input
              type="password"
              name="password"
              required
              value={form.password}
              placeholder=""
              onChange={handlePasswordChange}
              maxLength="20"
            />
            <label htmlFor="password">Password</label>
            {errors.password && (
              <span className="error-text">{errors.password}</span>
            )}
          </div>

          {/* Always display Security Questions */}
          {form.securityQuestions.map((qna, index) => (
            <div key={index} className="input-group">
              {/* <label>Select Question {index + 1}</label> */}
              <select
                required
                value={qna.securityQuestion}
                onChange={(e) => handleQuestionChange(index, e.target.value)}
                onBlur={() =>
                  handleSecurityBlur(
                    index,
                    "securityQuestion",
                    qna.securityQuestion
                  )
                }
              >
                <option value="">Choose Security Question No.{index + 1}</option>
                {securityQuestionsList
                  .filter(
                    (q) =>
                      !form.securityQuestions
                        .map((sq) => sq.securityQuestion)
                        .includes(q) || q === qna.securityQuestion
                  )
                  .map((securityQuestion, idx) => (
                    <option key={idx} value={securityQuestion}>
                      {securityQuestion}
                    </option>
                  ))}
              </select>
              {errors.securityQuestions[index] &&
                errors.securityQuestions[index].securityQuestion && (
                  <span className="error-text">
                    {errors.securityQuestions[index].securityQuestion}
                  </span>
                )}

              {/* <label>Answer</label> */}
              <input
                type="text"
                required
                value={qna.securityAnswer}
                placeholder="Enter Your Answer"
                onChange={(e) => handleAnswerChange(index, e.target.value)}
                onBlur={() =>
                  handleSecurityBlur(
                    index,
                    "securityAnswer",
                    qna.securityAnswer
                  )
                }
              />
              {errors.securityQuestions[index] &&
                errors.securityQuestions[index].securityAnswer && (
                  <span className="error-text">
                    {errors.securityQuestions[index].securityAnswer}
                  </span>
                )}
            </div>
          ))}
        </div>

        <button type="submit" disabled={loading}>
          {loading ? "Signing up..." : "Sign Up"}
        </button>
      </form>
    </div>
  );
};

export default SignupForm;
