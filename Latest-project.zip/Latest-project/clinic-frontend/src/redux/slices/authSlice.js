import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { loginUser, signupUser, refreshToken } from '../../api/authApi';
import Cookies from 'js-cookie';


const rawUser = Cookies.get('user');
const userFromCookie = rawUser ? JSON.parse(rawUser) : null;

// automatically handled by extraReducers
export const login = createAsyncThunk('auth/login', async (data, thunkAPI) => {
    // auth/login/pending, auth/login/fulfilled, auth/login/rejected
    try {
        const res = await loginUser(data);
        return res.data;
    } catch (err) {
        console.log(err.response.data?.error)
        return thunkAPI.rejectWithValue(err.response?.data?.error || 'Login failed');
    }
});


export const signup = createAsyncThunk('auth/signup', async (data, thunkAPI) => {
    try {
        const res = await signupUser(data);
        return res.data;
    } catch (err) {
        console.log('Full error:', err.response?.data);
        const errorMessage =
            err.response?.data?.message ||
            err.response?.data?.error ||
            'Signup failed';
        return thunkAPI.rejectWithValue(errorMessage);
    }
});

// Function to refresh the token
export const refreshAccessToken = createAsyncThunk(
    'auth/refreshToken',
    async (_, thunkAPI) => {
        try {
            const response = await refreshToken();
            console.log(response);
            return response;
        } catch (error) {
            console.error("Error refreshing token:", error);
            return thunkAPI.rejectWithValue(
                error.response?.data?.error || 'Refresh token failed'
            );
        }
    }
);



const authSlice = createSlice({
    name: 'auth',
    initialState: {
        user: userFromCookie,
        loading: false,
        error: null,
    },
    reducers: {
        logout: (state) => {
            state.user = null;
            Cookies.remove('token');
            Cookies.remove('user');
            Cookies.remove('refreshToken')
        },
    },
    extraReducers: (builder) => {
        builder
            // Signup Cases
            .addCase(signup.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(signup.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload.user;
            })
            .addCase(signup.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload || 'Signup failed';
            })

            // Login Cases
            .addCase(login.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(login.fulfilled, (state, action) => {
                state.loading = false;

                // extracting user from response
                const user = action.payload.user || {
                    username: action.payload.username,
                    role: action.payload.role,
                    name: action.payload.name,
                };
                state.user = user;
                Cookies.set('refreshToken', action.payload.refreshToken);
                Cookies.set('token', action.payload.accessToken);
                Cookies.set('user', JSON.stringify(user)); // username, name and role everythin i am setting in user
            })

            .addCase(login.rejected, signup.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            // ===== Refresh Token Cases =====
            .addCase(refreshAccessToken.pending, (state) => {
                state.loading = true;
            })
            .addCase(refreshAccessToken.fulfilled, (state, action) => {
                state.loading = false;
                // Saving the refreshed access token in a cookie.
                Cookies.set('token', action.payload.accessToken);
            })
            .addCase(refreshAccessToken.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            });
        ;
    },
});


export const { logout } = authSlice.actions;
export default authSlice.reducer;
