import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import NavBar from "./components/common/NavBar";
import BookAppointment from "./pages/BookAppointment";
import ActiveAppointments from "./pages/ActiveAppointments";
import AppointmentHistory from "./pages/AppointmentHistory";
import ProtectedRoute from "./components/common/ProtectedRoute";
import NotFound from "./pages/NotFound";
import "./App.css";
import HeroSection from "./pages/HeroSection";
import { refreshAccessToken } from "./redux/slices/authSlice";
import { useDispatch, useSelector } from "react-redux";
import Cookies from "js-cookie";
import { Box } from "@mui/material";

const App = () => {
  const dispatch = useDispatch();
  const { user, role } = useSelector((state) => state.auth);

  useEffect(() => {
    if (user) {
      const tokenRefreshInterval = setInterval(() => {
        dispatch(refreshAccessToken());
      }, 14 * 60 * 1000);
      return () => clearInterval(tokenRefreshInterval);
    }
  }, [user]);

  return (
    <>
      <NavBar />

      <Box sx={{ paddingTop: "64px" }}>
        <Routes>
          <Route path="/" element={<HeroSection />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/book"
            element={
              <ProtectedRoute>
                <BookAppointment />
              </ProtectedRoute>
            }
          />
          <Route
            path="/active"
            element={
              <ProtectedRoute>
                <ActiveAppointments />
              </ProtectedRoute>
            }
          />
          <Route
            path="/history"
            element={
              <ProtectedRoute>
                <AppointmentHistory />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Box>
    </>
  );
};

export default App;
