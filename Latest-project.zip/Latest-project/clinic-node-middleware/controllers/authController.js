const { generateAccessToken, generateRefreshToken, verifyRefreshToken } = require('../utils/jwtUtil');
const backendService = require('../services/backendService');
const validations = require('../utils/validations');
require('dotenv').config();

async function checkUsernameExist(req, res) {
  try {
    console.log("Check Username Controller");
    const { username } = req.query;
    console.log(username)
    const response = await backendService.checkUsernameExist({ username });
    console.log(response);
    res.status(200).json(response.data);
  } catch (err) {
    res.status(err.response?.status || 400).json({ error: err.response?.data || err.message });
  }
}

async function checkEmailExist(req, res) {
  try {
    console.log("Check Email Controller");
    const { email } = req.query; 
    console.log(email)
    const response = await backendService.checkEmailExist({ email });
    res.status(200).json(response.data);
  } catch (err) {
    res.status(err.response?.status || 400).json({ error: err.response?.data || err.message });
  }
}
async function getSecurityQuestionList (req, res){
  console.log("first");
  try{
    const response = await backendService.getSecurityQuestionList();
      res.json(response.data);
    } catch (err) {
      res
        .status(err.response?.status || 400)
        .json({ error: err.response?.data || err.message });
    }
}
async function getUsersSecurityQuestionList (req, res){
  const { username } = req.query; 
  try{
    const response = await backendService.getUsersSecurityQuestionList({username});
      res.json(response.data);
    } catch (err) {
      res
        .status(err.response?.status || 400)
        .json({ error: err.response?.data || err.message });
    }
}
async function signup(req, res) {
  try {
    const error = validations.validateSignupData(req.body);
    if (error) return res.status(400).json({ error });
    console.log(req.body);
    const { username, name, email, phoneNumber, password, role, securityQuestions } = req.body;

    await backendService.signup({ username, name, email, phoneNumber, password, role, securityQuestions });
    console.log('Signup successful')
    res.status(201).json({ message: 'Signup successful' });
  } catch (err) {
    console.error('Signup error:', err);

    // If axios error, extracting backend error message, status code
    if (err.response) {
      // console.log(err.response.data);
      return res.status(err.response.status).json({
        error: err.response.data || 'Signup failed',
      });
    }

    // If no response error message and 500 status
    res.status(500).json({ error: err.message || 'Signup failed' });
  }
}

async function login(req, res) {
  try {
    console.log(req.body)
    // Validating login data
    const error = validations.validateLoginData(req.body);
    if (error) return res.status(400).json({ error });

    const { username, password } = req.body;
    const userData = await backendService.login({ username, password });
    console.log(userData);
    if (!userData) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const payload = { username: userData.username, role: userData.role, name: userData.name };

    const accessToken = generateAccessToken(payload);
    const refreshToken = generateRefreshToken(payload);

    // res.cookie('refreshToken', refreshToken, {
    //   httpOnly: true,
    //   secure: process.env.NODE_ENV === 'production',
    //   sameSite: 'None',
    //   maxAge: 7 * 24 * 60 * 60 * 1000,
    // });

    res.json({
      accessToken,
      refreshToken,
      username: userData.username,
      name: userData.name,
      role: userData.role,
    });
    console.log('Login successful')
  } catch (err) {
    // If axios error, extracting backend error message, status code
    if (err.response) {
      return res.status(err.response.status).json({
        error: err.response.data || err.response.statusText || 'Signup failed',
      });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
}
async function verifySecurityQuestions(req, res) {
  try {
    console.log("Received payload:", req.body);
    // Pass the request body directly to the backend service.
    const isVerified = await backendService.verifySecurityQuestions(req.body);
    console.log("Verification result:", isVerified);
    res.json({ username: isVerified.username, isVerified: isVerified.verified });
  } catch (err) {
    // Extract error details if available from the backend error response.
    if (err.response) {
      return res.status(err.response.status).json({
        error: err.response.data || err.response.statusText || 'Verification Failed',
      });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function updatePassword(req, res) {
  try {
    const { username, verified, newPassword } = req.body;
    console.log(username, verified, newPassword );
    await backendService.updatePassword({ username, verified, newPassword });
    res.status(201).json({ message: 'Password successfully updated' });
  } catch (err) {
    // If axios error, extracting backend error message, status code
    if (err.response) {
      return res.status(err.response.status).json({
        error: err.response.data || 'Password Updation failed',
      });
    }
    res.status(500).json({ error: err.message || 'Signup failed' });
  }
}

async function refreshToken(req, res) {
  console.log(req.body);
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ error: 'Refresh token missing' });

  try {
    const payload = verifyRefreshToken(token);
    const newAccessToken = generateAccessToken({ username: payload.username, role: payload.role });
    res.json({ accessToken: newAccessToken });
    console.log("Refresh Token Generated")
  } catch (err) {
    res.status(403).json({ error: 'Invalid refresh token' });
  }
}

async function logout(req, res) {
  try {
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'None',
    });

    res.json({ message: 'Logout successful' });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = {
  checkUsernameExist,
  checkEmailExist,
  getSecurityQuestionList,
  getUsersSecurityQuestionList,
  signup,
  login,
  verifySecurityQuestions,
  updatePassword,
  refreshToken,
  logout,
};
