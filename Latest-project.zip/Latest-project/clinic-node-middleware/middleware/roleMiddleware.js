function authorizeRole(...allowedRoles) {
  return (req, res, next) => {
    console.log('User role:', req.user?.role);
    const userRole = req.user?.role;

    if (!userRole) {
      return res.status(401).json({ error: 'User role missing from request' });
    }

    if (!allowedRoles.includes(userRole)) {
      return res.status(403).json({ error: 'Access denied: insufficient permissions' });
    }

    next();
  };
}


module.exports = authorizeRole;
