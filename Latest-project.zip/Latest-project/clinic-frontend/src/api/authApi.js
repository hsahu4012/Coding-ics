import axios from 'axios';
import Cookies from 'js-cookie';
const BASE_URL = `${import.meta.env.VITE_API_BASE}/auth`;

export const getSecurityQuestions = async() => {
    const res = await axios.get(`${BASE_URL}/security-questions`);
    // console.log(res.data);
    return res.data; 
};
export const getUsersSecurityQuestions = async(forgotUsername) => {
  // console.log(data)
    const res = await axios.get(`${BASE_URL}/get-users-security-questions`, { params: { "username": forgotUsername }});
    // console.log(res.data);
    return res.data; 
};

export const refreshToken = async(data) => {
    try {
      console.log(Cookies.get());

    const headers = {
        authorization : Cookies.get('refreshToken')
    }
    // console.log(headers.authorization);
    const res = await axios.post(`${BASE_URL}/refresh-token` , {headers} , { withCredentials: true } );
    // console.log(res.data)
    return res.data; 
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

export const signupUser = (data) => axios.post(`${BASE_URL}/signup`, data, { withCredentials: true })
export const checkUsername = (data) => axios.get(`${BASE_URL}/username-check`, data);
export const checkEmail = (data) => axios.get(`${BASE_URL}/email-check`, data);
export const loginUser = (data) => axios.post(`${BASE_URL}/login`, data, { withCredentials: true });


