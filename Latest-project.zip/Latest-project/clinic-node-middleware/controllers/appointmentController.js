const backendService = require('../services/backendService');
const validations = require('../utils/validations');

async function getDoctorList(req, res) {
  try {
    console.log("getDoctorList Controller");
    const response = await backendService.getDoctorList();
    // console.log("response ="+ response);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}
async function getTopDoctorList(req, res) {
  try {
    console.log("Top Doctor");
    const response = await backendService.getTopDoctorList();
    // console.log("response ="+ response);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function bookAppointment(req, res) {
  try {
    const patientUsername = req.user.username;
    const { doctorUsername, newDateTime } = req.body;
    // console.log("doctorUsername" + doctorUsername + "newDateTime" + newDateTime);

    // Validate request body
    const error = validations.validateBookAppointment({ doctorUsername, patientUsername, newDateTime });
    if (error) return res.status(400).json({ error });

    const payload = { doctorUsername, patientUsername, newDateTime };
    const response = await backendService.bookAppointment(payload);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function cancelAppointment(req, res) {
  try {
    // console.log("Hello This is controller") 
    const {appointmentId} = req.body;
    // console.log(appointmentId);
    const username = req.user.username;
    const role = req.user.role;

    // Validate cancel appointment input
    const error = validations.validateCancelAppointment({ appointmentId, username, role });
    if (error) return res.status(400).json({ error });

    const response = await backendService.cancelAppointment(appointmentId, username, role);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function rescheduleAppointment(req, res) {
  try {
    console.log("Hello This is controller") 
    const username = req.user.username;
    const role = req.user.role;
    const requestData = req.body; // { appointmentId, newDateTime }

    // console.log("username " + username + " role " + role+ " newDateTime " + requestData);
    console.log(`username: ${username}, role: ${role}, newDateTime: ${JSON.stringify(requestData)}`);

    const { appointmentId, newDateTime } = requestData;
    // Validate reschedule input
    const error = validations.validateRescheduleAppointment({appointmentId, newDateTime, username, role });
    if (error) return res.status(400).json({ error });

    const response = await backendService.rescheduleAppointment(requestData, username, role);
    console.log(response.data);

    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function completeAppointment(req, res) {
  try {
    const doctorUsername = req.user.username;
    const { appointmentId, diagnosis, comments } = req.body; // { appointmentId, diagnosis, comments }

    // Validate complete appointment input
    const error = validations.validateCompleteAppointment( { appointmentId, diagnosis, comments, doctorUsername });
    if (error) return res.status(400).json({ error });

    const response = await backendService.completeAppointment( appointmentId, diagnosis, comments, doctorUsername);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}
async function getActiveAppointments(req, res) {
  try {
    // console.log(req.body);
    const username = req.user.username;
    const role=  req.user.role;

    // console.log(username, role);
    // Validate get active appointments input
    const error = validations.validateGetActiveAppointments({ username, role});
    if (error) return res.status(400).json({ error });

    const response = await backendService.getActiveAppointments(username, role);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function giveFeedback(req, res) {
  try {
    // console.log("Hello")
    // console.log(req.body);
    const patientUsername = req.user.username;
    // console.log(patientUsername)
    const { doctorUsername, feedbackRating, feedbackComment, appointmentId } = req.body;
    // console.log("doctorUsername" + doctorUsername + "newDateTime" + newDateTime);
    // console.log(patientUsername, doctorUsername, feedbackRating, feedbackComment, appointmentId )
    console.log(doctorUsername, patientUsername, feedbackRating, feedbackComment, appointmentId)

    const payload = { doctorUsername, patientUsername, rating: feedbackRating, feedbackComment, appointmentId };
    const response = await backendService.giveFeedback(payload);
    console.log(response.data)
    res.json("Feedback added");
  } catch (err) {
    console.log(err)
    res
      .status(err.response?.status || 400) 
      .json({ error: err.response?.data || err.message });
  }
}

async function getAppointmentHistoryForUser(req, res) {
  try {
    const username = req.user.username;
    const role = req.user.role;

    // Validate get appointment history input
    const error = validations.validateGetAppointmentHistory({ username, role });
    if (error) return res.status(400).json({ error });

    const response = await backendService.getAppointmentHistory(username, role);
    console.log(response.data)
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

async function searchCompletedAppointmentsByPatient(req, res) {
  try {
    const doctorUsername = req.user.username;
    const { patientUsername } = req.body;

    // Validate search completed appointments input
    const error = validations.validateSearchCompletedAppointments({ doctorUsername, patientUsername });
    if (error) return res.status(400).json({ error });

    const response = await backendService.searchCompletedAppointmentsByPatient(doctorUsername, patientUsername);
    res.json(response.data);
  } catch (err) {
    res
      .status(err.response?.status || 400)
      .json({ error: err.response?.data || err.message });
  }
}

module.exports = {
  getDoctorList,
  getTopDoctorList,
  bookAppointment,
  cancelAppointment,
  rescheduleAppointment,
  completeAppointment,
  getActiveAppointments,
  giveFeedback,
  getAppointmentHistoryForUser,
  searchCompletedAppointmentsByPatient,
};
