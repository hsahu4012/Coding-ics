import React, { useEffect, useState } from "react";
import { Button, Typography, Container, Box } from "@mui/material";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import Cookies from "js-cookie";
import "../styles/HeroSection.css";

const API_BASE = `${import.meta.env.VITE_API_BASE}/appointments`;

const HeroSection = () => {
  const { user } = useSelector((state) => state.auth);
  const [topDoctors, setTopDoctors] = useState([]);

  // Determining user role
  const isPatient = user?.role === "PATIENT";

  // Fetch top doctors only if the user is a patient
  useEffect(() => {
    if (isPatient) {
      axios
        .get(`${API_BASE}/top-doctors`, {
          headers: { authorization: Cookies.get("token") },
        })
        .then((response) => {
          setTopDoctors(response.data);
        })
        .catch((error) => console.error("Error fetching top doctors:", error));
    }
  }, [isPatient]);

  // content based on user role
  const content = {
    guest: {
      title: "Welcome to Clinic Appointment System",
      subtitle: "Book your appointments easily.",
      buttonText: "Get Started",
      buttonLink: "/signup",
    },
    patient: {
      title: `Welcome back, ${user?.name}!`,
      subtitle: "Ready to book your next appointment?",
      buttonText: "Book Now",
      buttonLink: "/book",
    },
    doctor: {
      title: `Hello Dr. ${user?.name}!`,
      subtitle: "Here are your active appointments.",
      buttonText: "View Active",
      buttonLink: "/active",
    },
  };

  const { title, subtitle, buttonText, buttonLink } = user
    ? content[user.role.toLowerCase()]
    : content.guest;

  return (
    <Box className="hero-container">
      <Container maxWidth="md" className="hero-content">
        <Typography
          variant="h2"
          component="h2"
          gutterBottom
          className="hero-title"
        >
          {title}
        </Typography>
        <Typography variant="h6" className="hero-subtitle">
          {subtitle}
        </Typography>
        <Box mt={4}>
          <Button
            variant="contained"
            color="primary"
            size="large"
            component={Link}
            to={buttonLink}
            className="hero-button"
          >
            {buttonText}
          </Button>
        </Box>

        {/* Show top doctors only if the user is a patient */}
        {isPatient && topDoctors.length > 0 && (
          <Box mt={6}>
            <Typography variant="h4" gutterBottom>
              Our Top Rated Doctors
            </Typography>
            <Box className="doctor-card-container">
              {topDoctors.map((doctor) => (
                <Box key={doctor.username} className="doctor-card" mb={4}>
                  <Typography variant="h5">Dr. {doctor.name}</Typography>
                  <Typography variant="subtitle1">
                    @{doctor.username}
                  </Typography>
                  <Typography variant="body2">
                    Completed Appointments: {doctor.completedAppointments}
                  </Typography>
                  <Typography variant="body2">
                    Rating: {doctor.averageRating?.toFixed(1)}
                  </Typography>
                  <Button
                    variant="outlined"
                    color="secondary"
                    component={Link}
                    to={`/book?doctor=${doctor.username}`}
                    className="book-button"
                  >
                    Book Appointment
                  </Button>
                </Box>
              ))}
            </Box>
          </Box>
        )}
      </Container>
    </Box>
  );
};

export default HeroSection;
