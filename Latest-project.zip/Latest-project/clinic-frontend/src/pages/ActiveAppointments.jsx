import React, { useEffect, useState } from "react";
import "../styles/ActiveAppointments.css";
import {
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Pagination,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchActiveAppointments,
  cancelAppointmentThunk,
  rescheduleAppointmentThunk,
  completeAppointmentThunk,
} from "../redux/slices/appointmentSlice";
import { toast } from "react-toastify";
const getCurrentTimeString = () => {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();

  // Zero-pad hours and minutes
  return `${hours.toString().padStart(2, "0")}:${minutes
    .toString()
    .padStart(2, "0")}`;
};
const ActiveAppointments = () => {
  const dispatch = useDispatch();
  const { active } = useSelector((state) => state.appointments);
  const { user } = useSelector((state) => state.auth);

  console.log(active);
  // today's date in "YYYY-MM-DD"
  const today = new Date().toISOString().split("T")[0];
  // current time in "HH:MM" format
  const currentTime = getCurrentTimeString();

  // Local state for pagination
  const [page, setPage] = useState(1);
  const appointmentsPerPage = 5;
  const totalPages = Math.ceil(active.length / appointmentsPerPage);
  const displayedAppointments = active.slice(
    (page - 1) * appointmentsPerPage,
    page * appointmentsPerPage
  );

  const [rescheduleDialog, setRescheduleDialog] = useState({
    open: false,
    appointmentId: null,
    date: "",
    time: "",
  });
  // Dialog state for completing appointments
  const [completeDialog, setCompleteDialog] = useState({
    open: false,
    id: null,
    diagnosis: "",
    comments: "",
  });
  // Dialog for cancelling appointments
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);

  useEffect(() => {
    dispatch(fetchActiveAppointments());
  }, [dispatch]);

  const handleOpenDialog = (appointment) => {
    setSelectedAppointment(appointment);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedAppointment(null);
  };

  const handleConfirmCancel = () => {
    if (selectedAppointment) {
      handleCancel(selectedAppointment.appointmentId);
    }
    handleCloseDialog();
  };

  const handleCancel = async (appointmentId) => {
    try {
      await dispatch(cancelAppointmentThunk(appointmentId)).unwrap();
      toast.success("Appointment Cancelled successfully.");
    } catch (err) {
      toast.error("Failed to cancel appointment: " + err.message);
    }
  };

  // Open reschedule dialog
  const openRescheduleDialog = (appt) => {
    const dt = new Date(appt.dateTime);
    const isoDate = dt.toISOString().split("T")[0];
    const isoTime = dt.toTimeString().substring(0, 5);
    setRescheduleDialog({
      open: true,
      appointmentId: appt.appointmentId,
      date: isoDate,
      time: isoTime,
    });
  };
  // Close reschedule dialog
  const closeRescheduleDialog = () => {
    setRescheduleDialog({
      open: false,
      appointmentId: null,
      date: "",
      time: "",
    });
  };

  // Handle reschedule date/time change
  const handleRescheduleChange = (e) => {
    setRescheduleDialog((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // Submit reschedule
  const handleRescheduleSubmit = async () => {
    const { appointmentId, date, time } = rescheduleDialog;
    if (!date || !time) {
      toast("Please select date and time.");
      return;
    }
    const localOffset = "+05:30";
    const newDateTime = `${date}T${time}:00.000${localOffset}`;

    if (new Date(newDateTime) < new Date()) {
      toast.error("Cannot reschedule to past time.");
      return;
    }

    try {
      console.log(appointmentId, newDateTime);
      await dispatch(
        rescheduleAppointmentThunk({ appointmentId, newDateTime })
      ).unwrap();
      closeRescheduleDialog();
      toast.success("Appointment Rescheduled successfully.");
    } catch (err) {}
  };

  const openCompleteDialog = (id) => {
    setCompleteDialog({ open: true, id, diagnosis: "", comments: "" });
  };

  const submitCompletion = () => {
    const { id, diagnosis, comments } = completeDialog;
    if (!diagnosis || !comments) return toast("Please fill all fields.");
    dispatch(
      completeAppointmentThunk({ appointmentId: id, diagnosis, comments })
    );
    setCompleteDialog({ open: false, id: null, diagnosis: "", comments: "" });
  };

  return (
    <Box className="active-appointments-container">
      <Typography variant="h5" gutterBottom>
        Active Appointments
      </Typography>
      <List className="active-appointments-list">
        {active.length === 0 ? (
          <ListItem className="active-appointment-item">
            <ListItemText
              align="center"
              primary="No Active appointments found."
            />
          </ListItem>
        ) : (
          displayedAppointments.map((appt) => {
            const dt = new Date(appt.dateTime);
            return (
              <ListItem
                key={appt.appointmentId}
                divider
                className="active-appointment-item"
              >
                {user.role === "DOCTOR" && (
                  <ListItemText
                    primary={`Patient: ${appt.patientName}`}
                    secondary={`Date: ${dt.toLocaleDateString()} ${dt.toLocaleTimeString(
                      [],
                      {
                        hour: "2-digit",
                        minute: "2-digit",
                      }
                    )}`}
                  />
                )}
                {user.role === "PATIENT" && (
                  <ListItemText
                    primary={`Doctor: ${appt.doctorName}`}
                    secondary={`Date: ${dt.toLocaleDateString()} ${dt.toLocaleTimeString(
                      [],
                      {
                        hour: "2-digit",
                        minute: "2-digit",
                      }
                    )}`}
                  />
                )}
                <Button
                  className="cancel-margin"
                  variant="outlined"
                  color="error"
                  onClick={() => handleOpenDialog(appt)}
                  style={{ marginRight: "8px" }}
                >
                  Cancel
                </Button>
                <Button
                  variant="outlined"
                  sx={{ mr: 1 }}
                  onClick={() => openRescheduleDialog(appt)}
                >
                  Reschedule
                </Button>
                {user.role === "DOCTOR" && (
                  <Button
                    variant="contained"
                    onClick={() => openCompleteDialog(appt.appointmentId)}
                    color="success"
                  >
                    Complete
                  </Button>
                )}
              </ListItem>
            );
          })
        )}
      </List>

      {/* Pagination */}
      {totalPages > 1 && (
        <Box className="pagination-container">
          <Pagination
            count={totalPages}
            page={page}
            onChange={(event, value) => setPage(value)}
            color="primary"
          />
        </Box>
      )}

      {/* Cancel Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>
          Are you sure you want to cancel this appointment?
        </DialogTitle>
        <DialogContent>
          <p>This action cannot be undone.</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} variant="outlined">
            No
          </Button>
          <Button
            onClick={handleConfirmCancel}
            color="error"
            variant="contained"
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reschedule Dialog */}
      <Dialog open={rescheduleDialog.open} onClose={closeRescheduleDialog}>
        <DialogTitle>Reschedule Appointment</DialogTitle>
        <DialogContent>
          <TextField
            label="Date"
            type="date"
            name="date"
            value={rescheduleDialog.date}
            onChange={handleRescheduleChange}
            fullWidth
            margin="normal"
            InputLabelProps={{ shrink: true }}
            inputProps={{ min: today }}
          />
          <TextField
            label="Time"
            type="time"
            name="time"
            value={rescheduleDialog.time}
            onChange={handleRescheduleChange}
            fullWidth
            margin="normal"
            InputLabelProps={{ shrink: true }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={closeRescheduleDialog} variant="contained">Cancel</Button>
          <Button
            onClick={handleRescheduleSubmit}
            className="save-btn"
            variant="contained"
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* Complete Dialog */}
      <Dialog
        open={completeDialog.open}
        onClose={() => setCompleteDialog({ ...completeDialog, open: false })}
      >
        <DialogTitle>Complete Appointment</DialogTitle>
        <DialogContent>
          <TextField
            label="Diagnosis"
            fullWidth
            multiline
            margin="normal"
            value={completeDialog.diagnosis}
            onChange={(e) =>
              setCompleteDialog({
                ...completeDialog,
                diagnosis: e.target.value,
              })
            }
          />
          <TextField
            label="Comments"
            fullWidth
            multiline
            margin="normal"
            value={completeDialog.comments}
            onChange={(e) =>
              setCompleteDialog({
                ...completeDialog,
                comments: e.target.value,
              })
            }
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() =>
              setCompleteDialog({ ...completeDialog, open: false })
            }
            variant="contained"
          >
            Cancel
          </Button>

          <Button onClick={submitCompletion} variant="contained">Submit</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ActiveAppointments;
