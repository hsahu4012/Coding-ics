const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');


// My All ROutes
router.get('/username-check', authController.checkUsernameExist);
router.get('/email-check', authController.checkEmailExist);
router.get('/security-questions', authController.getSecurityQuestionList);
router.get('/get-users-security-questions', authController.getUsersSecurityQuestionList);

router.post('/signup', authController.signup);
router.post('/login', authController.login);

// router.post('/verify-security-question', authController.verifySecurityQuestion);
router.post('/verify-security-questions', authController.verifySecurityQuestions);
router.put('/update-password', authController.updatePassword);
router.post('/refresh-token', authController.refreshToken);
router.post('/logout', authController.logout);

module.exports = router;
