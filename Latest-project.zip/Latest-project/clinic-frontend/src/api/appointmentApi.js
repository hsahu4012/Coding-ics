import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';

const API_BASE = `${import.meta.env.VITE_API_BASE}/appointments`;

// Book new appointment
export const bookAppointment = async (appointmentData) => {
    try {
        const headers = {
            authorization: Cookies.get('token')
        }
        const res = await axios.post(`${API_BASE}/book`, appointmentData, {
            headers,
            withCredentials: true
        });
        console.log(res);
        return res.data;
    } catch (error) {
        // console.log(error.response?.data.error)
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

// Get active appointments for logged in patient
export const getActiveAppointments = async () => {

    try {
        const headers = {
            authorization: Cookies.get('token')
        }
        console.log(headers);
        
        const res = await axios.get(`${API_BASE}/active`, { headers });
        console.log(res);
        return res.data;
    } catch (error) {
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

// Cancel appointment
export const cancelAppointment = async (appointmentId) => {
    try {
        const headers = {
            authorization: Cookies.get('token')
        }
        const res = await axios.put(`${API_BASE}/cancel`, { appointmentId }, {
            headers,
            withCredentials: true
        });
        console.log(res);
        return res.data;
    } catch (error) {
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

// Reschedule appointment
export const rescheduleAppointment = async (appointmentId, newDateTime) => {
    try {
        const headers = {
            authorization: Cookies.get('token')
        }
        console.log(appointmentId, newDateTime);

        const res = await axios.put(
            `${API_BASE}/reschedule`,
            { appointmentId, newDateTime },
            {
                headers,
                withCredentials: true
            }
        );
        console.log(res);
        return res.data;
    } catch (error) {
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

// Complete appointment (doctor only)
export const completeAppointment = async (appointmentId, diagnosis, comments) => {
    try {
        const headers = {
            authorization: Cookies.get('token')
        }

        console.log(appointmentId, diagnosis, comments)
        const res = await axios.put(
            `${API_BASE}/complete`,
            { appointmentId, diagnosis, comments },
            {
                headers,
                withCredentials: true
            }
        );
        return res.data;
    } catch (error) {
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

// Get completed appointments
export const getCompletedAppointments = async () => {
    try {
        const headers = {
            authorization: Cookies.get('token')
        }
        const res = await axios.get(`${API_BASE}/history`, {
            headers
        }
        );
        return res.data;
    } catch (error) {
        toast.error(error.response?.data?.error || error.message || 'Failed to book appointment');
        throw error.response?.data?.error || error.message;
    }
};

