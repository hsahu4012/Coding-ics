const axios = require('axios');
require('dotenv').config();
const baseURL = process.env.SPRING_BOOT_BASE_URL;

const backend = axios.create({
    baseURL,
    timeout: 5000,
});

backend.defaults.withCredentials = true;

async function getDoctorList() {
    return backend.get('/auth/getdoctor');
}
async function getTopDoctorList() {
    return backend.get('/auth/top');
}

async function checkUsernameExist({ username }) {
    return backend.get(`/auth/username-check?username=${username}`);
}

async function checkEmailExist({ email }) {
    return backend.get(`/auth/email-check?email=${email}`);
}
async function getSecurityQuestionList() {
    return backend.get('/security-questions/list');
}

async function getUsersSecurityQuestionList({ username }) {
    return backend.get(`/security-questions/${username}`);
}


// Signup new user
async function signup(userData) {
    // console.log('Signup user data:', userData);
    return axios.post(`${baseURL}/auth/signup`, userData);
}

// Login user
async function login({ username, password }) {
    // console.log(username, password);
    const response = await backend.post('/auth/login', { username, password });
    // console.log(response);
    return response.data;
}
//verify Security Question
async function verifySecurityQuestions(requestPayload) {
  console.log("Verifying Security Questions with payload:", requestPayload);
  // Call the backend API and pass the payload directly.
  const response = await backend.post('/auth/verify-security-question', requestPayload);
  return response.data;
}
//update Password
async function updatePassword({ username, verified, newPassword }){
    console.log("Verifying Password Updation")
    return await backend.put('/auth/update-password', { username, verified, newPassword });
}

// Book an appointment
// data = { doctorUsername, patientUsername, newDateTime }
async function bookAppointment(data) {
    console.log('Booking appointment:', data);
    return backend.post('/appointments/book', data, { withCredentials: true });
}
// Fetch active appointments for a patient
async function getActiveAppointments(username, role) {
  return backend.get('/appointments/active', {
    params: { username, role },
  });
}

// Cancel an appointment by ID
// Sends username and role as query params
async function cancelAppointment(appointmentId, username, role) {
    return backend.put(
        `/appointments/cancel/${appointmentId}`,
        {}, // no request body
        {
            params: { username, role },
        }
    );
}

// Reschedule an appointment by ID
// sends { appointmentId, newDateTime } in body
async function rescheduleAppointment(requestData, username, role) {
    // requestData = { appointmentId, newDateTime }
    const { appointmentId, newDateTime } = requestData;
    console.log(appointmentId, newDateTime ); 

    return backend.put(
        `/appointments/reschedule`,
        { appointmentId, newDateTime },
        {
            params: { username, role },
        }
    );
}

// Complete an appointment by ID (only doctor allowed)
// requestData = { appointmentId, diagnosis, comments }
async function completeAppointment( appointmentId, diagnosis, comments, doctorUsername) {

    return backend.put(
        `/appointments/complete`,
        { appointmentId, diagnosis, comments },
        {
            params: { doctorUsername },
        }
    );
}

//Give Feedback
async function giveFeedback( {doctorUsername, patientUsername, rating, feedbackComment, appointmentId }) {
    console.log(doctorUsername, patientUsername, rating, feedbackComment, appointmentId)
    console.log("Working ")
    return backend.post(
        `/feedback`,
        {rating, feedbackComment, patientUsername, doctorUsername, appointmentId },
    );
}

// Get appointment history for user (doctor or patient)
async function getAppointmentHistory(username, role) {
    return backend.get('/appointments/history', {
        params: { username, role },
    });
}

// Search completed appointments
// doctorUsername: logged in doctor
// patientUsername: patient username to search for
async function searchCompletedAppointmentsByPatient(doctorUsername, patientUsername) {
    return backend.get('/appointments/doctor/search', 
        {
        params: { doctorUsername, patientUsername },
    });
}

module.exports = {
    getDoctorList,
    getTopDoctorList,
    checkUsernameExist,
    checkEmailExist,
    getSecurityQuestionList,
    getUsersSecurityQuestionList,
    signup,
    login,
    // verifySecurityQuestion,
    verifySecurityQuestions,
    updatePassword,
    bookAppointment,
    getActiveAppointments,
    cancelAppointment,
    rescheduleAppointment,
    completeAppointment,
    giveFeedback,
    getAppointmentHistory,
    searchCompletedAppointmentsByPatient,
};
