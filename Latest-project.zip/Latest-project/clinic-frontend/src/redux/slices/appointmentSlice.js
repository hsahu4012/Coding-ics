import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {
    getActiveAppointments,
    bookAppointment,
    cancelAppointment,
    rescheduleAppointment,
    getCompletedAppointments,
    completeAppointment,
} from '../../api/appointmentApi';

// Async thunks
export const fetchActiveAppointments = createAsyncThunk('appointments/fetchActive', async (_, thunkAPI) => {
    try {
        return await getActiveAppointments();
    } catch (error) {
        return thunkAPI.rejectWithValue(error);
    }
});

export const createAppointment = createAsyncThunk('appointments/book', async (appointmentData, thunkAPI) => {
    try {
        return await bookAppointment(appointmentData);
        
    } catch (error) {
        console.log(error);
        return thunkAPI.rejectWithValue(error);
    }
});

export const cancelAppointmentThunk = createAsyncThunk('appointments/cancel', async (appointmentId, thunkAPI) => {
    try {
        return await cancelAppointment(appointmentId);
    } catch (error) {
        return thunkAPI.rejectWithValue(error);
    }
});

export const rescheduleAppointmentThunk = createAsyncThunk(
    'appointments/reschedule',
    async ({ appointmentId, newDateTime }, thunkAPI) => {
        try {
            console.log(appointmentId, newDateTime);
            return await rescheduleAppointment(appointmentId, newDateTime);
        } catch (error) {
            return thunkAPI.rejectWithValue(error);
        }
    }
);

export const fetchCompletedAppointments = createAsyncThunk(
    'appointments/history',
    async (_, thunkAPI) => {
        try {
            return await getCompletedAppointments();
        } catch (error) {
            return thunkAPI.rejectWithValue(error);
        }
    }
);

// Thunk to complete appointment
export const completeAppointmentThunk = createAsyncThunk(
    'appointments/complete',
    async ({ appointmentId, diagnosis, comments }, thunkAPI) => {
        try {
            return await completeAppointment(appointmentId, diagnosis, comments);
        } catch (error) {
            return thunkAPI.rejectWithValue(error);
        }
    }
);


const appointmentSlice = createSlice({
    name: 'appointments',
    initialState: {
        active: [],
        completed: [],
        loading: false,
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchActiveAppointments.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchActiveAppointments.fulfilled, (state, action) => {
                state.loading = false;
                state.active = action.payload;
            })
            .addCase(fetchActiveAppointments.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            // Create new appointment
            .addCase(createAppointment.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(createAppointment.fulfilled, (state, action) => {
                state.loading = false;
                state.active.push(action.payload);
            })
            .addCase(createAppointment.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            // Cancel appointment
            .addCase(cancelAppointmentThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(cancelAppointmentThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.active = state.active.filter(
                    (appt) => appt.appointmentId !== action.meta.arg
                );
            })
            .addCase(cancelAppointmentThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            // Reschedule appointment
            .addCase(rescheduleAppointmentThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(rescheduleAppointmentThunk.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.active.findIndex(
                    (appt) => appt.appointmentId === action.meta.arg.appointmentId
                );
                if (index !== -1) {
                    state.active[index] = action.payload;
                }
            })
            .addCase(rescheduleAppointmentThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            // Fetch completed appointments
            .addCase(fetchCompletedAppointments.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchCompletedAppointments.fulfilled, (state, action) => {
                state.loading = false;
                state.completed = action.payload;
            })
            .addCase(fetchCompletedAppointments.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            // Complete appointment
            .addCase(completeAppointmentThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(completeAppointmentThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.active = state.active.filter(
                    (a) => a.appointmentId !== action.meta.arg.appointmentId
                );
                state.completed.push(action.payload);
            })
            .addCase(completeAppointmentThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            });
    },
});

export default appointmentSlice.reducer;
