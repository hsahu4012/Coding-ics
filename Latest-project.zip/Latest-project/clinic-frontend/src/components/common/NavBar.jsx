import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  useMediaQuery,
  useTheme,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Box,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { NavLink, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../../redux/slices/authSlice";
import "../../styles/NavBar.css";

const NavBar = () => {
  const { user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleLogout = () => {
    dispatch(logout());
    navigate("/");
  };

  const toggleDrawer = (open) => () => {
    setDrawerOpen(open);
  };

  const navItems = [
    { label: "Home", path: "/" },
    ...(user?.role === "PATIENT"
      ? [{ label: "Book", path: "/book" }, {label: "Active", path: "/active"}]
      : []),
    ...(user?.role === "DOCTOR" ? [{ label: "Active", path: "/active" }] : []),
    ...(user ? [{ label: "History", path: "/history" }] : []),
    ...(user
      ? [{ label: "Logout", action: handleLogout }]
      : [
          { label: "Sign Up", path: "/signup" },
          { label: "Log In", path: "/login" },
        ]),
  ];

  const renderDrawerItems = () => (
    <Box
      className="mobileDrawer"
      role="presentation"
      onClick={toggleDrawer(false)}
    >
      <List>
        {navItems.map((item, index) => (
          <ListItem
            key={index}
            className="mobileDrawerItem"
            onClick={item.action || (() => navigate(item.path))}
          >
            <ListItemText
              primary={item.label}
              primaryTypographyProps={{ className: "mobileDrawerText" }}
            />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <AppBar position="fixed" className="appbar ">
      <Toolbar className="toolbar" sx={{ justifyContent: "space-between" }}>
        <Typography
          variant="h6"
          component={NavLink}
          to="/"
          className="title"
          sx={{ textDecoration: "none", color: "white" }}
        >
          Clinic Appointment Scheduling
        </Typography>

        {isMobile ? (
          <>
            <IconButton edge="end" color="inherit" onClick={toggleDrawer(true)}>
              <MenuIcon />
            </IconButton>
            <Drawer
              anchor="right"
              open={drawerOpen}
              onClose={toggleDrawer(false)}
            >
              {renderDrawerItems()}
            </Drawer>
          </>
        ) : (
          <div>
            <NavLink
              to="/"
              end
              className={({ isActive }) =>
                isActive ? "navButton navButtonActive" : "navButton"
              }
            >
              <Button
                color="inherit"
                sx={{ textTransform: "none", fontWeight: 600 }}
              >
                Home
              </Button>
            </NavLink>

            {user?.role === "PATIENT" && (
              <NavLink
                to="/book"
                className={({ isActive }) =>
                  isActive ? "navButton navButtonActive" : "navButton"
                }
              >
                <Button
                  color="inherit"
                  sx={{ textTransform: "none", fontWeight: 600 }}
                >
                  Book
                </Button>
              </NavLink>
            )}

            {user && (
              <NavLink
                to="/active"
                className={({ isActive }) =>
                  isActive ? "navButton navButtonActive" : "navButton"
                }
              >
                <Button
                  color="inherit"
                  sx={{ textTransform: "none", fontWeight: 600 }}
                >
                  Active
                </Button>
              </NavLink>
            )}

            {user && (
              <NavLink
                to="/history"
                className={({ isActive }) =>
                  isActive ? "navButton navButtonActive" : "navButton"
                }
              >
                <Button
                  color="inherit"
                  sx={{ textTransform: "none", fontWeight: 600 }}
                >
                  History
                </Button>
              </NavLink>
            )}

            {user ? (
              <Button
                color="inherit"
                onClick={handleLogout}
                sx={{ textTransform: "none", fontWeight: 600 }}
              >
                Logout
              </Button>
            ) : (
              <>
                <NavLink
                  to="/signup"
                  className={({ isActive }) =>
                    isActive ? "navButton navButtonActive" : "navButton"
                  }
                >
                  <Button
                    color="inherit"
                    sx={{ textTransform: "none", fontWeight: 600 }}
                  >
                    Sign Up
                  </Button>
                </NavLink>
                <NavLink
                  to="/login"
                  className={({ isActive }) =>
                    isActive ? "navButton navButtonActive" : "navButton"
                  }
                >
                  <Button
                    color="inherit"
                    sx={{ textTransform: "none", fontWeight: 600 }}
                  >
                    Log In
                  </Button>
                </NavLink>
              </>
            )}
          </div>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
