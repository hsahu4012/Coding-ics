import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { login } from "../../redux/slices/authSlice";
import {
  Button,
  TextField,
  Box,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  InputAdornment,
  IconButton,
} from "@mui/material";
import { Visibility, VisibilityOff } from '@mui/icons-material';

import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { getUsersSecurityQuestions } from "../../api/authApi";
import axios from "axios";

const BASE_URL = `${import.meta.env.VITE_API_BASE}/auth`;

// ----- PASSWORD VALIDATOR FUNCTION -----
// Returns an error message if the password does not meet criteria,
// or an empty string if it does.
const validatePassword = (value) => {
  if (/\s/.test(value)) return "Password cannot contain spaces.";
  if (value.length < 8) return "Password must be at least 8 characters long.";
  if (!/[A-Z]/.test(value))
    return "Password must include at least one uppercase letter.";
  if (!/[a-z]/.test(value))
    return "Password must include at least one lowercase letter.";
  if (!/\d/.test(value)) return "Password must include at least one number.";
  if (!/[@$!%*#?&]/.test(value))
    return "Password must include at least one special character (@$!%*#?&).";
  return "";
};

const LoginForm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, user } = useSelector((state) => state.auth);

  const [form, setForm] = useState({ username: "", password: "" });

  const [showPassword, setShowPassword] = useState(false);
   const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleClickShowPassword = () => setShowPassword((prev) => !prev);
  const handleClickShowConfirmPassword = () => setShowConfirmPassword((prev) => !prev);
  /*
    Forgot Password flow states:
    - Step 1: Username Verification Dialog
    - Step 2: Security Questions Dialog
    - Step 3: Set New Password Dialog
  */
  // Step 1 states
  const [forgotUsernameDialogOpen, setForgotUsernameDialogOpen] =
    useState(false);
  const [forgotUsername, setForgotUsername] = useState("");
  const [usernameError, setUsernameError] = useState("");

  // Step 2 states – security questions and respective answers/errors.
  const [securityQuestionsDialogOpen, setSecurityQuestionsDialogOpen] =
    useState(false);
  const [securityQuestions, setSecurityQuestions] = useState([]);
  const [securityAnswers, setSecurityAnswers] = useState({
    answer1: "",
    answer2: "",
    answer3: "",
  });
  const [securityAnswersErrors, setSecurityAnswersErrors] = useState({
    answer1: "",
    answer2: "",
    answer3: "",
  });

  // Step 3 states – new password dialog.
  const [setNewPasswordDialogOpen, setSetNewPasswordDialogOpen] =
    useState(false);
  const [usernameFromReset, setUsernameFromReset] = useState("");
  const [newPasswordData, setNewPasswordData] = useState({
    newPassword: "",
    confirmNewPassword: "",
  });
  const [passwordError, setPasswordError] = useState("");

  // Login form submission handler
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(login(form))
      .unwrap()
      .then(() => {
        toast.success("Login successful!");
      })
      .catch((err) => {
        toast.error(err || "Login failed. Please try again.");
      });
  };

  // Redirect based on user role if signed in
  useEffect(() => {
    if (user) {
      console.log("Redirecting based on role:", user.role);
      if (user.role === "DOCTOR" || user.role === "PATIENT") {
        navigate("/");
      }
    }
  }, [user, navigate]);

  // ================================================
  // Forgot Password – Step 1: Username Verification
  // ================================================
  const openForgotPassword = () => {
    // Reset the state for username verification.
    setForgotUsername("");
    setUsernameError("");
    setForgotUsernameDialogOpen(true);
  };

  // When the user clicks the “Proceed” button, we check the username.
  const handleForgotUsernameProceed = async () => {
    if (!forgotUsername.trim()) {
      toast.error("Please enter a username.");
      return;
    }
    try {
      const response = await axios.get(`${BASE_URL}/username-check`, {
        params: { username: forgotUsername },
      });
      if (response.data !== "Username already exists") {
        setUsernameError("Username not exist");
        // toast.error("Username not exist");
        return;
      } else {
        setUsernameError("");
        // Fetch security questions for the valid username.
        const questions = await getUsersSecurityQuestions(forgotUsername);
        if (questions.length < 3) {
          toast.error("Security questions are not available.");
          return;
        }
        setSecurityQuestions(questions);
        // Saving the username for later steps.
        setUsernameFromReset(forgotUsername);
        // Transition to step 2 and clear answers.
        setForgotUsernameDialogOpen(false);
        setSecurityQuestionsDialogOpen(true);
        setSecurityAnswers({ answer1: "", answer2: "", answer3: "" });
        setSecurityAnswersErrors({ answer1: "", answer2: "", answer3: "" });
      }
    } catch (err) {
      console.error(err);
      toast.error("Error verifying username. Please try again.");
    }
  };

  // ================================================
  // Forgot Password – Step 2: Security Questions
  // ================================================
  const handleSecurityAnswerChange = (e) => {
    const { name, value } = e.target;
    setSecurityAnswers((prev) => ({ ...prev, [name]: value }));
  };

  // When the user clicks “Verify”, sending the three questions and answers.
  const handleVerifySecurityAnswers = async () => {
    const payload = {
      username: usernameFromReset,
      questions: [
        { question: securityQuestions[0], answer: securityAnswers.answer1 },
        { question: securityQuestions[1], answer: securityAnswers.answer2 },
        { question: securityQuestions[2], answer: securityAnswers.answer3 },
      ],
    };
    console.log(payload);
    try {
      const { data: result } = await axios.post(
        `${BASE_URL}/verify-security-questions`,
        payload
      );
      // API returns an object like:
      // { isVerified: boolean, usernaem}
      if (result.isVerified) {
        toast.success(
          "Security details verified. Please set your new password."
        );
        setSecurityQuestionsDialogOpen(false);
        setSetNewPasswordDialogOpen(true);
      } else if (result.errors) {
        // Set error messages per field.
        setSecurityAnswersErrors({
          answer1: result.errors.answer1 || "",
          answer2: result.errors.answer2 || "",
          answer3: result.errors.answer3 || "",
        });
      } else {
        toast.error("Verification failed. Please try again.");
      }
    } catch (err) {
      console.error(err);
      toast.error(
        err.response?.data?.error || "Verification failed. Please try again."
      );
    }
  };

  // ================================================
  // Forgot Password – Step 3: Set New Password
  // ================================================
  const handleNewPasswordInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "newPassword") {
      const validationMessage = validatePassword(value);
      setPasswordError(validationMessage);
    }
    setNewPasswordData((prev) => ({ ...prev, [name]: value }));
  };

  // On clicking the Update Password button, validate and update the password.
  const handleSubmitNewPassword = async () => {
    if (!newPasswordData.newPassword || !newPasswordData.confirmNewPassword) {
      toast.error("Both password fields are required.");
      return;
    }
    if (newPasswordData.newPassword !== newPasswordData.confirmNewPassword) {
      toast.error("Passwords do not match.");
      return;
    }
    if (passwordError) {
      toast.error(passwordError);
      return;
    }
    try {
      const { data } = await axios.put(`${BASE_URL}/update-password`, {
        verified: true,
        username: usernameFromReset,
        newPassword: newPasswordData.newPassword,
      });
      toast.success("Password updation successful.");
      // Clear all related states after successful update.
      setNewPasswordData({ newPassword: "", confirmNewPassword: "" });
      setPasswordError("");
      setSetNewPasswordDialogOpen(false);
      navigate("/login");
    } catch (err) {
      toast.error(
        err.response?.data?.error || "Password update failed. Please try again."
      );
    }
  };

  return (
    <>
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{
          maxWidth: 400,
          mx: "auto",
          mt: 5,
          p: 4,
          backgroundColor: "#ffffff",
          borderRadius: 2,
          boxShadow: "0 2px 20px rgba(0,0,0,0.1)",
        }}
        className="login-form-container"
      >
        <Typography
          variant="h4"
          align="center"
          gutterBottom
          sx={{ fontWeight: "bold", color: "#333" }}
        >
          Log In
        </Typography>
        <TextField
          label="Username"
          fullWidth
          margin="normal"
          required
          value={form.username}
          onChange={(e) => setForm({ ...form, username: e.target.value })}
          variant="outlined"
          className="custom-textfield"
        />
        <TextField
          label="Password"
          type={showPassword ? "text" : "password"}
          fullWidth
          margin="normal"
          required
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          variant="outlined"
          className="custom-textfield"
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleClickShowPassword} edge="end">
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <Button
          type="submit"
          variant="contained"
          fullWidth
          disabled={loading}
          sx={{ mt: 2, py: 1.5, fontSize: "1rem" }}
          className="primary-button"
        >
          {loading ? "Logging in..." : "Login"}
        </Button>
        <Typography
          variant="body2"
          align="center"
          sx={{
            mt: 2,
            cursor: "pointer",
            color: "#1976d2",
            textDecoration: "underline",
          }}
          onClick={openForgotPassword}
          className="forgot-password"
        >
          Forgot Password?
        </Typography>
      </Box>

      {/* ---------------------------------------------- */}
      {/* Step 1: Forgot Password – Username Verification */}
      {/* ---------------------------------------------- */}
      <Dialog
        open={forgotUsernameDialogOpen}
        onClose={() => setForgotUsernameDialogOpen(false)}
        classes={{ paper: "custom-dialog" }}
      >
        <DialogTitle className="dialog-title">Forgot Password</DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="Username"
            fullWidth
            variant="outlined"
            value={forgotUsername}
            onChange={(e) => setForgotUsername(e.target.value)}
            error={Boolean(usernameError)}
            helperText={usernameError}
            className="custom-textfield"
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setForgotUsernameDialogOpen(false)}
            className="primary-button"
            variant="contained"
          >
            Cancel
          </Button>
          <Button
            onClick={handleForgotUsernameProceed}
            variant="contained"
            className="primary-button"
          >
            Proceed
          </Button>
        </DialogActions>
      </Dialog>

      {/* ---------------------------------------------- */}
      {/* Step 2: Forgot Password – Security Questions */}
      {/* ---------------------------------------------- */}
      <Dialog
        open={securityQuestionsDialogOpen}
        onClose={() => setSecurityQuestionsDialogOpen(false)}
        classes={{ paper: "custom-dialog" }}
      >
        <DialogTitle className="dialog-title">
          Answer Security Questions
        </DialogTitle>
        <DialogContent>
          {securityQuestions.length >= 3 && (
            <>
              <TextField
                margin="dense"
                label={securityQuestions[0]}
                name="answer1"
                fullWidth
                variant="outlined"
                value={securityAnswers.answer1}
                onChange={handleSecurityAnswerChange}
                error={Boolean(securityAnswersErrors.answer1)}
                helperText={securityAnswersErrors.answer1}
                className="custom-textfield"
              />
              <TextField
                margin="dense"
                label={securityQuestions[1]}
                name="answer2"
                fullWidth
                variant="outlined"
                value={securityAnswers.answer2}
                onChange={handleSecurityAnswerChange}
                error={Boolean(securityAnswersErrors.answer2)}
                helperText={securityAnswersErrors.answer2}
                className="custom-textfield"
              />
              <TextField
                margin="dense"
                label={securityQuestions[2]}
                name="answer3"
                fullWidth
                variant="outlined"
                value={securityAnswers.answer3}
                onChange={handleSecurityAnswerChange}
                error={Boolean(securityAnswersErrors.answer3)}
                helperText={securityAnswersErrors.answer3}
                className="custom-textfield"
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setSecurityQuestionsDialogOpen(false)}
            className="primary-button"
            variant="contained"
          >
            Cancel
          </Button>
          <Button
            onClick={handleVerifySecurityAnswers}
            variant="contained"
            className="primary-button"
          >
            Verify
          </Button>
        </DialogActions>
      </Dialog>

      {/* ---------------------------------------------- */}
      {/* Step 3: Forgot Password – Set New Password */}
      {/* ---------------------------------------------- */}
      <Dialog
        open={setNewPasswordDialogOpen}
        onClose={() => setSetNewPasswordDialogOpen(false)}
        classes={{ paper: "custom-dialog" }}
      >
        <DialogTitle className="dialog-title">
          Set New Password for {usernameFromReset}
        </DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="New Password"
            name="newPassword"
            type={showPassword ? "text" : "password"}
            fullWidth
            variant="outlined"
            value={newPasswordData.newPassword}
            onChange={handleNewPasswordInputChange}
            error={Boolean(passwordError)}
            helperText={passwordError}
            className="custom-textfield"
            InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleClickShowPassword} edge="end">
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            ),
          }}
          />
          <TextField
            margin="dense"
            label="Confirm New Password"
            name="confirmNewPassword"
            type={showConfirmPassword ? "text" : "password"}
            fullWidth
            variant="outlined"
            value={newPasswordData.confirmNewPassword}
            onChange={handleNewPasswordInputChange}
            className="custom-textfield"
            InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleClickShowConfirmPassword} edge="end">
                  {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            ),
          }}
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setSetNewPasswordDialogOpen(false)}
            className="primary-button"
            variant="contained"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmitNewPassword}
            variant="contained"
            className="primary-button"
          >
            Update Password
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default LoginForm;
