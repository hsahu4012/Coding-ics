function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhoneNumber(phone) {
  return /^\+?\d{10,15}$/.test(phone);
}

function isValidDateOfBirth(dateStr) {
  const date = new Date(dateStr);
  return !isNaN(date) && date < new Date();
}


function isValidDate(dateStr) {
  return !isNaN(Date.parse(dateStr));
}


function validateSignupData(data) {
  const { username, name, email, phoneNumber, password, role } = data;

  if (!username || !name || !email || !phoneNumber|| !password || !role) {
    return 'All fields are required';
  }
  if (username.length < 3 || username.length > 30) {
    return 'Username must be between 3 and 30 characters';
  }
  const alphabetCount = (username.match(/[a-zA-Z]/g) || []).length;
  if (alphabetCount < 2) {
    return 'Username must contain at least two alphabets';
  }

  if (name.length < 3 || name.length > 50) {
    return 'Name must be between 3 and 50 characters';
  }
  
  // Allow letters (a-z, A-Z), spaces, apostrophes, hyphens
  const validNameRegex = /^[a-zA-Z\s]+$/;
  if (!validNameRegex.test(name)) {
    return "Name can only contain letters, spaces";
  }

  if (!isValidEmail(email)) {
    return 'Invalid email format';
  }

  if (!isValidPhoneNumber(phoneNumber)) {
    return 'Invalid phone number format';
  }

  if (!['PATIENT', 'DOCTOR'].includes(role.toUpperCase())) {
    return 'Role must be PATIENT or DOCTOR';
  }
  if (password.length < 6) {
    return 'Password must be at least 6 characters';
  }
  
  console.log("All are Valid");
  return null; // no error
}

function validateLoginData(data) {
  const { username, password } = data;
  if (!username || !password) {
    return 'Username and password are required';
  }
  if (username.length < 3 || username.length > 30) {
    return 'Username must be between 3 and 30 characters';
  }
  if (password.length < 6) {
    return 'Password must be at least 6 characters';
  }
  return null;
}

function validateBookAppointment(data) {
  const { doctorUsername, patientUsername, newDateTime } = data;
  
  if (!doctorUsername || !patientUsername || !newDateTime) {
    return 'doctorUsername, patientUsername and newDateTime are required';
  }

  if (!isValidDate(newDateTime)) {
    return 'Invalid date/time for appointment';
  }

  return null;
}

function validateCancelAppointment(data) {
  const { appointmentId, username, role } = data;
  if (!appointmentId || !username || !role) {
    return 'appointmentId, username, and role are required for canceling appointment';
  }
  return null;
}

function validateRescheduleAppointment(data) {
  const { appointmentId, newDateTime, username, role } = data;
  if (!appointmentId || !newDateTime || !username || !role) {
    return 'appointmentId, newDateTime, username, and role are required for rescheduling appointment';
  }
  if (!isValidDate(newDateTime)) {
    return 'Invalid newDateTime for rescheduling';
  }
  return null;
}

function validateCompleteAppointment(data) {
  const { appointmentId, diagnosis, comments, doctorUsername } = data;
  if (!appointmentId || !diagnosis || !comments || !doctorUsername) {
    return 'appointmentId, diagnosis, comments, and doctorUsername are required for completing appointment';
  }

  if (diagnosis.trim().length === 0 || comments.trim().length === 0) {
    return 'Diagnosis and comments cannot be empty';
  }
// console.log("No error");
  return null;
}

function validateGetActiveAppointments(data) {
  const { username, role } = data;
  if (!username || !role) {
    return 'username and role are required';
  }
  return null;
}

function validateGetAppointmentHistory(data) {
  const { username, role } = data;
  if (!username || !role) {
    return 'username and role are required';
  }
  return null;
}

function validateSearchCompletedAppointments(data) {
  const { doctorUsername, patientUsername } = data;
  if (!doctorUsername || !patientUsername) {
    return 'doctorUsername and patientUsername are required';
  }
  return null;
}

module.exports = {
  validateSignupData,
  validateLoginData,
  validateBookAppointment,
  validateCancelAppointment,
  validateRescheduleAppointment,
  validateCompleteAppointment,
  validateGetActiveAppointments,
  validateGetAppointmentHistory,
  validateSearchCompletedAppointments,
};
